#!/usr/bin/env bash
# ============================================================
#  ASCII 入口 —— 等同于 `bash 一键安装.sh`
#  某些解压工具会把中文文件名弄成乱码，用本文件可避免踩坑。
# ============================================================

HERE="$(cd "$(dirname "$0")" && pwd)"
TARGET="$HERE/一键安装.sh"

if [ ! -f "$TARGET" ]; then
  # 中文名可能被解压成乱码，按通配兜底查找
  TARGET="$(ls "$HERE"/*.sh 2>/dev/null | grep -v '/install\.sh$' | head -n 1)"
fi

if [ -z "${TARGET:-}" ] || [ ! -f "$TARGET" ]; then
  echo "[错误] 未找到安装脚本，请确认 zip 已完整解压。" >&2
  exit 1
fi

echo "[信息] 使用安装脚本: $(basename "$TARGET")"
exec bash "$TARGET" "$@"
