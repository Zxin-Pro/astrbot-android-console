# AstrBot + NapCat 安卓懒人包

> 在**安卓手机本地**跑起一套完整的 QQ 机器人：AstrBot（AI 对话框架）+ NapCat（QQ 协议端）。
> **不需要电脑、不需要 VPS、不需要 root**，全程在 Termux 里一条命令搞定。

---

## 一、这个包做了什么

它会自动完成下面这一长串又容易踩坑的操作：

1. 在 Termux 里创建 Debian 容器（`proot-distro`），名字叫 `astrbot`
2. 在容器内安装 **QQ 客户端 + NapCat**（走 NapCat 官方安装脚本）
3. 在容器内安装 **uv**，再用 uv 装 **AstrBot**（自动配好 Python 3.12）
4. 初始化 AstrBot 数据目录，并**自动写入 OneBot v11(aiocqhttp) 平台配置**
5. **自动预置 NapCat 的反向 WS 配置**，让它开机就主动连上 AstrBot（`ws://127.0.0.1:6199/ws`）
6. 生成一整套管理命令：启动 / 停止 / 状态 / 登录 / 日志 / 更新 / 卸载

也就是说：正常情况下你**只需要一条安装命令 + 扫一次码**。

---

## 二、准备工作

| 项目 | 要求 |
|---|---|
| 手机系统 | Android（arm64 优先，x86_64 也支持） |
| 内存 | **建议 4GB 以上**（QQ + AstrBot 同时跑比较吃内存） |
| 存储 | 预留 **3GB 以上** |
| Termux | **请从 [F-Droid](https://f-droid.org/packages/com.termux/) 或 [GitHub Releases](https://github.com/termux/termux-app/releases) 下载**，Google Play 版已停止更新，装不了 |

> ⚠️ 一定要用 F-Droid / GitHub 版 Termux。Play 商店版本仓库地址失效，`pkg install` 会直接报错。

Termux 装好后，建议先执行一次：

```bash
pkg update -y && pkg upgrade -y
termux-setup-storage      # 允许访问手机存储（方便把 zip 放进家目录）
```

---

## 三、快速开始（三步）

### 第 1 步：把包放进来

把 `astrbot-napcat-安卓懒人包.zip` 传到手机上，然后在 Termux 里解压到**家目录**：

```bash
cd ~
# 如果 zip 放在手机存储的 Download 目录：
unzip /sdcard/Download/astrbot-napcat-安卓懒人包.zip -d ~/
cd ~/astrbot-napcat-android
```

> 若提示 `unzip` 不存在：`pkg install unzip`

### 第 2 步：一键安装

```bash
bash 一键安装.sh
```

> 如果解压后中文文件名显示为乱码，改用 ASCII 入口即可：
> ```bash
> bash install.sh
> ```

想顺便预填 QQ 号（以后启动免扫码）：

```bash
bash 一键安装.sh --qq 你的QQ号
```

国外网络可以加 `--no-cn` 关掉国内镜像加速。

这一步会跑 **5~15 分钟**（主要时间花在下载 QQ 和 AstrBot 依赖上），中途**别关 Termux**。

### 第 3 步：启动 + 扫码登录

```bash
bash ~/astrbot-napcat/abot start     # 启动两个服务
bash ~/astrbot-napcat/abot login     # 看扫码登录指引（会给一个带 token 的直达链接）
```

拿到链接后，在**手机浏览器**打开 → 面板显示二维码 → **截图** → 打开手机 QQ → 右上角 `+` → 扫一扫 → 右上角「相册」→ 选那张截图 → 确认登录。

登录成功后，NapCat 会自动连上 AstrBot（6199），你就拥有一个跑在手机里的 QQ 机器人了。

---

## 四、命令速查

所有命令都可以通过 `abot` 这一个入口调用：

```bash
bash ~/astrbot-napcat/abot help
```

| 命令 | 作用 |
|---|---|
| `bash abot start` | 启动 AstrBot + NapCat（后台） |
| `bash abot stop` | 停止全部 |
| `bash abot restart` | 重启全部 |
| `bash abot status` | 查看运行状态、端口、登录账号 |
| `bash abot login` | 获取 QQ 扫码登录方式 / NapCat 面板直达链接 |
| `bash abot logs [napcat\|astrbot]` | 查看日志 |
| `bash abot update` | 更新 NapCat 与 AstrBot |
| `bash abot shell` | 进入容器命令行 |
| `bash abot install` | 重跑安装（补装 / 修复，已装部分自动跳过） |
| `bash abot uninstall` | 彻底卸载（删容器 + 数据） |

> 嫌 `bash ~/astrbot-napcat/abot` 太长，可以加个快捷方式：
> ```bash
> echo 'alias abot="bash ~/astrbot-napcat/abot"' >> ~/.bashrc && source ~/.bashrc
> ```
> 之后直接 `abot start` 即可。

---

## 五、面板地址

在**手机浏览器**里打开（都是本机地址，不对外）：

| 面板 | 地址 | 说明 |
|---|---|---|
| AstrBot 管理面板 | http://127.0.0.1:6185 | 配置大模型、插件、查看对话 |
| NapCat 管理面板 | http://127.0.0.1:6099 | QQ 登录、网络配置（token 见 `abot login`） |

AstrBot 首次登录：用户名一般是 `astrbot`，**随机初始密码**在启动日志里打印（`abot logs astrbot` 可以看到）。

---

## 六、让机器人真正能聊天

装好只是"通了管道"，要能对话还得配一个大模型：

1. 浏览器打开 AstrBot 面板 `http://127.0.0.1:6185`，登录
2. 左侧 **服务提供商** → **新增** → 选你的厂商（OpenAI / DeepSeek / Gemini / 通义千问…）
3. 填入 **API Key** 和模型名 → 保存
4. 到 **配置** 页把「默认对话模型」设成刚添加的
5. 用你的 QQ 给机器人私聊发一句，或在群里 **@它**，就能收到回复

> 默认情况下机器人只响应「@ 它」和私聊。要让它响应所有群消息，去 AstrBot 的**平台设置**里改触发规则。

---

## 七、工作原理

```
┌─────────────── 安卓手机（Termux）───────────────┐
│                                                  │
│   proot-distro Debian 容器  "astrbot"            │
│   ┌──────────────────────────────────────────┐   │
│   │  xvfb  ←  QQ(linux-arm64)  ←  NapCat     │   │
│   │              │                           │   │
│   │              │ 反向 WebSocket             │   │
│   │              ▼  ws://127.0.0.1:6199/ws    │   │
│   │           AstrBot (aiocqhttp 适配器)       │   │
│   │              │                           │   │
│   │              └── 管理面板 :6185            │   │
│   └──────────────────────────────────────────┘   │
│                                                  │
│   浏览器访问 127.0.0.1:6185 / :6099 即可管理      │
└──────────────────────────────────────────────────┘
```

- QQ 在容器里以**无头模式**运行（xvfb 提供虚拟显示，不需要真的显示画面）
- NapCat 注入 QQ 进程，把 QQ 能力暴露成 OneBot v11 协议
- AstrBot 用 aiocqhttp 适配器**监听 6199**，NapCat 主动连上来（反向 WS）
- 两者都在同一容器里，所以走 `127.0.0.1` 通信，无需任何端口映射

---

## 八、常见问题

### 1. 安装卡在下载 / 下载失败
多试几次。也可以在安装时**不用** `--no-cn`（默认就用国内镜像）。
如果 GitHub 相关下载失败，包内已内置 `ghfast.top → ghproxy.net → 直连` 三重回退。

### 2. 内存不够 / 进程被杀
安卓后台管理很激进。请在系统设置里给 **Termux 加白名单**（允许后台活动、关闭省电限制），
并尽量只在需要时启动服务：平时 `abot stop`，用时 `abot start`。

### 3. 面板打开是空白页
AstrBot 的 Web UI 资源首次可能需要联网下载。确认网络正常后 `abot restart`；
日志里有 `Dashboard is ready` 字样即成功。

### 4. QQ 登录后又掉线 / 被踢
- 同一个 QQ 号不要同时在多处登录 NapCat
- 换设备登录后，旧的登录态会失效，重新 `abot login` 扫码即可
- 首次登录建议立刻在 QQ 里勾选「自动登录」本地设备，之后可用 `--qq` 快速登录

### 5. 机器人不回复
按顺序检查：
1. `abot status` 看两个服务是否都在运行
2. AstrBot 面板 → 平台，看 `aiocqhttp` 是否显示**已连接**；没连上就 `abot restart`
3. 是否已经配置了**大模型服务提供商**（第六节）
4. 群里需要 **@机器人** 才会响应（默认行为）

### 6. 想换端口 / 改配置
- AstrBot：面板里改，或 `abot shell` 进去编辑 `/root/AstrBot/data/cmd_config.json`
- NapCat：面板 (6099) → 网络配置，或改 `/root/Napcat/.../napcat/config/onebot11_<QQ>.json`
- 如果改了 NapCat 的连接目标，记得两边端口要一致（默认 6199）

### 7. 关掉 Termux 后机器人还活着吗？
不会。Termux 被系统杀掉后服务就停了。要保持在线，请：
- 给 Termux 开「后台运行 / 电池不优化」
- 或使用 `termux-wake-lock` 命令申请唤醒锁

---

## 九、卸载

```bash
bash ~/astrbot-napcat/abot uninstall
```

会询问两次确认：先删容器（连同 QQ 登录态和 AstrBot 数据），再问是否删脚本目录。

---

## 十、重要提示

- **本包完全在本机运行，所有服务只监听 `127.0.0.1`**，不要自行把它们暴露到公网。
  一旦把 6099/6185 映射到公网，等于把 QQ 和面板交给全网，非常危险。
- NapCat 属于**第三方 QQ 框架**，腾讯官方并不支持，理论上存在**账号风险**。
  建议**使用小号**，不要拿主力号冒险。
- 请遵守当地法律法规以及腾讯的用户协议，仅用于学习与个人用途。

---

## 十一、包内文件

```
astrbot-napcat-android/
├── 一键安装.sh              ← 主安装入口（在 Termux 里运行这个）
├── abot                     ← 统一命令入口
├── README.md                ← 本文档
├── VERSION                  ← 版本信息
├── ctl/
│   ├── start.sh             启动
│   ├── stop.sh              停止
│   ├── restart.sh           重启
│   ├── status.sh            状态
│   ├── login.sh             登录指引
│   ├── logs.sh              日志
│   ├── update.sh            更新
│   └── uninstall.sh         卸载
└── container/
    ├── install.sh           容器内安装逻辑（QQ/NapCat/AstrBot）
    ├── start-napcat.sh      容器内启动 NapCat
    ├── start-astrbot.sh     容器内启动 AstrBot
    ├── stop-all.sh          容器内停止全部
    ├── patch_astrbot.py     自动注入 aiocqhttp 平台配置
    └── onebot11.json        NapCat 反向 WS 预设配置
```

---

## 十二、构建时的上游版本

| 组件 | 版本 |
|---|---|
| NapCat | v4.18.33 |
| AstrBot | 4.28.x（安装时取最新） |
| Debian rootfs | 由 proot-distro 提供 |

> 安装脚本均从上游官方源实时拉取，因此你拿到的通常是更新的版本。
