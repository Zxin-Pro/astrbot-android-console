#!/usr/bin/env bash
# ============================================================
#  AstrBot + NapCat 安卓懒人包 · 一键安装
#  适用: Android + Termux（无需 root，无需电脑）
#  原理: 在 Termux 内创建 Debian 容器(proot-distro)，
#        容器内装 QQ + NapCat + AstrBot 并自动对接。
#
#  用法: bash 一键安装.sh [--cn|--no-cn] [--qq 你的QQ号]
# ============================================================
set -o pipefail

if [ -t 1 ]; then
  R=$'\033[1;31m'; G=$'\033[1;32m'; Y=$'\033[1;33m'; C=$'\033[1;36m'; B=$'\033[1m'; N=$'\033[0m'
else
  R=''; G=''; Y=''; C=''; B=''; N=''
fi
info(){ printf '%s\n' "${C}[信息]${N} $*"; }
ok(){   printf '%s\n' "${G}[成功]${N} $*"; }
warn(){ printf '%s\n' "${Y}[注意]${N} $*"; }
die(){  printf '%s\n' "${R}[错误]${N} $*" >&2; exit 1; }
step(){ printf '\n%s\n' "${B}====  $*  ====${N}"; }

# ---------------- 参数 ----------------
CT="astrbot"
USE_CN=1
QQNUM=""
while [ $# -gt 0 ]; do
  case "$1" in
    --cn)      USE_CN=1 ;;
    --no-cn)   USE_CN=0 ;;
    --qq)      shift; QQNUM="${1:-}" ;;
    --qq=*)    QQNUM="${1#--qq=}" ;;
    -h|--help)
      cat <<'EOT'
用法: bash 一键安装.sh [选项]

选项:
  --cn            使用国内镜像加速（默认开启）
  --no-cn         不使用镜像，走官方源
  --qq <QQ号>     预先填好 QQ 号，之后启动可免扫码快速登录
  -h, --help      显示帮助
EOT
      exit 0 ;;
    *) die "未知参数: $1（可用 -h 查看帮助）" ;;
  esac
  shift
done

printf '%s\n' "${B}================================================${N}"
printf '%s\n' "${B}     AstrBot + NapCat 安卓懒人包 · 一键安装${N}"
printf '%s\n' "${B}================================================${N}"
printf '%s\n' "  容器名 : $CT"
printf '%s\n' "  镜像源 : $([ "$USE_CN" = 1 ] && echo '国内加速' || echo '官方源')"
[ -n "$QQNUM" ] && printf '%s\n' "  预置QQ : $QQNUM"
echo

# ---------------- 0. 环境检查 ----------------
step "0/6  环境检查"
if [ -z "${PREFIX:-}" ] || [ ! -d "$PREFIX" ]; then
  die "请在 Termux 中运行本脚本（当前环境不是 Termux）。安装 Termux 建议从 F-Droid 下载。"
fi
ok "检测到 Termux 环境"

ARCH="$(uname -m)"
case "$ARCH" in
  aarch64|arm64) ok "CPU 架构: $ARCH（arm64，官方支持）" ;;
  x86_64|amd64)  ok "CPU 架构: $ARCH（x86_64，官方支持）" ;;
  *) warn "CPU 架构 $ARCH 未经验证，QQ 可能无法运行" ;;
esac

MEM_MB="$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo 2>/dev/null)"
if [ -n "$MEM_MB" ]; then
  if [ "$MEM_MB" -lt 3500 ]; then
    warn "总内存约 ${MEM_MB}MB，建议 4GB 以上，否则 QQ + AstrBot 同时跑可能被杀"
  else
    ok "总内存约 ${MEM_MB}MB"
  fi
fi

FREE_MB="$(df -m "$PREFIX" 2>/dev/null | awk 'NR==2{print $4}')"
if [ -n "$FREE_MB" ] && [ "$FREE_MB" -lt 2500 ]; then
  warn "可用存储约 ${FREE_MB}MB，建议预留 3GB 以上"
fi

# ---------------- 1. 基础组件 ----------------
step "1/6  安装 Termux 基础组件"
if command -v pkg >/dev/null 2>&1; then PM="pkg"; else PM="apt"; fi
$PM update -y >/dev/null 2>&1 || true
$PM install -y proot-distro screen curl wget tar unzip \
  || die "基础组件安装失败（可尝试先执行: pkg update）"
ok "proot-distro / screen / curl 等已就绪"

# ---------------- 2. 容器 ----------------
step "2/6  准备 Debian 容器"
ROOTFS="$PREFIX/var/lib/proot-distro/installed-rootfs/$CT"
if [ -d "$ROOTFS" ]; then
  ok "容器 '$CT' 已存在，跳过下载"
else
  info "首次需要下载 Debian rootfs（约 100MB），请保持网络畅通 ..."
  proot-distro install debian --override-alias "$CT" \
    || die "容器创建失败。多为网络问题，可重试；或执行: proot-distro clear-cache"
  ok "容器 '$CT' 创建完成"
fi

# ---------------- 3. 投放脚本 ----------------
step "3/6  把安装脚本放进容器"
[ -d "$ROOTFS/root" ] || mkdir -p "$ROOTFS/root" || die "无法写入容器目录"
HERE="$(cd "$(dirname "$0")" && pwd)"
for f in install.sh start-napcat.sh start-astrbot.sh stop-all.sh onebot11.json patch_astrbot.py; do
  [ -f "$HERE/container/$f" ] || die "缺少文件: container/$f（请确认 zip 解压完整）"
  cp -f "$HERE/container/$f" "$ROOTFS/root/$f" || die "复制 $f 失败"
done
chmod +x "$ROOTFS/root"/*.sh 2>/dev/null
ok "脚本已就位"

# ---------------- 4. 容器内安装 ----------------
step "4/6  容器内安装 QQ + NapCat + AstrBot"
warn "这是最耗时的一步（约 5~15 分钟，取决于网速），其间请勿关闭 Termux"
echo
if [ "$USE_CN" = 1 ]; then FLAG="--cn"; else FLAG="--no-cn"; fi
proot-distro login "$CT" -- bash /root/install.sh $FLAG \
  || die "容器内安装失败，请查看上方日志；修复后可用 'bash 一键安装.sh' 重跑（已装部分会跳过）"
echo

# ---------------- 5. 生成管理命令 ----------------
step "5/6  生成管理命令"
DEST="$HOME/astrbot-napcat"
mkdir -p "$DEST" || die "创建 $DEST 失败"
if [ "$HERE" != "$DEST" ]; then
  cp -rf "$HERE"/. "$DEST"/ 2>/dev/null || warn "部分文件复制失败，可手动把整个文件夹移到 $DEST"
fi
chmod +x "$DEST/abot" "$DEST/一键安装.sh" 2>/dev/null
chmod +x "$DEST"/ctl/*.sh 2>/dev/null
if [ -n "$QQNUM" ]; then
  printf '%s\n' "$QQNUM" > "$DEST/qq.txt"
  ok "已记录 QQ 号 $QQNUM（启动时自动快速登录）"
fi
ok "管理命令已安装到: $DEST"

# ---------------- 6. 完成 ----------------
step "6/6  安装完成"
cat <<EOT

  ✅ 全部就绪！

  常用命令（在 Termux 执行）：
      bash ~/astrbot-napcat/abot start      # 启动 AstrBot + NapCat
      bash ~/astrbot-napcat/abot login      # 查看 QQ 扫码登录方式
      bash ~/astrbot-napcat/abot status     # 查看运行状态
      bash ~/astrbot-napcat/abot logs        # 查看日志
      bash ~/astrbot-napcat/abot help        # 全部命令

  面板地址（手机浏览器打开）：
      AstrBot : http://127.0.0.1:6185
      NapCat  : http://127.0.0.1:6099

  首次使用顺序：
      1) bash ~/astrbot-napcat/abot start
      2) bash ~/astrbot-napcat/abot login   （照着提示扫码登录 QQ）
      3) 打开 AstrBot 面板，配置你的大模型 API Key 即可开聊

EOT
