#!/usr/bin/env bash
# 停止容器内的 NapCat / AstrBot 进程
set -o pipefail

export HOME=/root

echo "[信息] 正在停止 NapCat / AstrBot ..."

# QQ / NapCat
pkill -f 'resources/app/app_launcher' 2>/dev/null
pkill -f 'xvfb-run' 2>/dev/null
pkill -f 'Xvfb' 2>/dev/null

# AstrBot（避免误杀本脚本自身）
for pid in $(pgrep -f 'astrbot' 2>/dev/null); do
  [ "$pid" = "$$" ] && continue
  kill "$pid" 2>/dev/null
done

sleep 1
pkill -9 -f 'resources/app/app_launcher' 2>/dev/null
pkill -9 -f 'Xvfb' 2>/dev/null

echo "[信息] 已停止。"
