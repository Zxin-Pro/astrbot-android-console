#!/usr/bin/env bash
# 启动 NapCat（QQ + NapCat 注入），可选传入 QQ 号做快速登录
# 用法: bash start-napcat.sh [QQ号]
set -o pipefail

export HOME=/root
export PATH="/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

QQ_DIR="/root/Napcat/opt/QQ"
QQ_BIN=""
for c in "$QQ_DIR/qq" /opt/QQ/qq; do
  if [ -x "$c" ]; then QQ_BIN="$c"; break; fi
done

if [ -z "$QQ_BIN" ]; then
  echo "[错误] 未找到 QQ 可执行文件，请先执行安装脚本。" >&2
  exit 1
fi

ARGS="--no-sandbox"
if [ -n "${1:-}" ]; then
  ARGS="$ARGS -q $1"
  echo "[信息] 使用快速登录，账号：$1"
else
  echo "[信息] 未指定 QQ 号：首次启动需扫码登录（见登录说明）"
fi

echo "[信息] 启动 NapCat ..."
echo "[信息] NapCat 面板 WebUI 默认端口 6099"

mkdir -p /root/logs
exec xvfb-run -a "$QQ_BIN" $ARGS
