#!/usr/bin/env bash
# 启动 AstrBot（管理面板 http://127.0.0.1:6185）
set -o pipefail

export HOME=/root
export PATH="/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

ASTRBOT_DIR="/root/AstrBot"

if [ ! -d "$ASTRBOT_DIR" ]; then
  echo "[错误] 未找到 $ASTRBOT_DIR，请先执行安装脚本。" >&2
  exit 1
fi

if [ ! -x /root/.local/bin/astrbot ]; then
  echo "[错误] 未找到 astrbot 命令，请先执行安装脚本。" >&2
  exit 1
fi

cd "$ASTRBOT_DIR" || exit 1

echo "[信息] 启动 AstrBot ..."
echo "[信息] 管理面板: http://127.0.0.1:6185  (首次启动会打印随机初始密码)"

exec /root/.local/bin/astrbot run
