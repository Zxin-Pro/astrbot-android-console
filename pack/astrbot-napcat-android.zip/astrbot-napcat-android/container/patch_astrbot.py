#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""向 AstrBot 的 cmd_config.json 注入 aiocqhttp (OneBot v11) 平台配置。

用法: python3 patch_astrbot.py [cmd_config.json 路径]
默认路径: /root/AstrBot/data/cmd_config.json
"""
import json
import os
import shutil
import sys

DEFAULT_PATH = "/root/AstrBot/data/cmd_config.json"


def main() -> int:
    path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_PATH
    if not os.path.isfile(path):
        print("[错误] 配置文件不存在: %s" % path)
        return 1

    try:
        with open(path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception as e:
        print("[错误] 解析 JSON 失败: %s" % e)
        return 1

    platform = cfg.get("platform")
    if not isinstance(platform, list):
        platform = []
        cfg["platform"] = platform

    found = False
    for p in platform:
        if isinstance(p, dict) and p.get("type") == "aiocqhttp":
            found = True
            p.setdefault("id", "napcat")
            p["enable"] = True
            p["ws_reverse_host"] = p.get("ws_reverse_host") or "0.0.0.0"
            p["ws_reverse_port"] = p.get("ws_reverse_port") or 6199
            p.setdefault("ws_reverse_token", "")
            print("[信息] 已存在 aiocqhttp 平台，已补齐必要字段")
            break

    if not found:
        platform.append({
            "id": "napcat",
            "type": "aiocqhttp",
            "enable": True,
            "ws_reverse_host": "0.0.0.0",
            "ws_reverse_port": 6199,
            "ws_reverse_token": "",
        })
        print("[信息] 已添加 aiocqhttp (OneBot v11) 平台")

    bak = path + ".bak"
    if not os.path.exists(bak):
        shutil.copy2(path, bak)
        print("[信息] 已备份原配置到 %s" % bak)

    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

    print("[成功] 平台配置已写入: %s" % path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
