#!/usr/bin/env bash
# ============================================================
#  AstrBot + NapCat 安卓懒人包 · 容器内安装脚本
#  在 Debian (proot-distro) 容器内以 root 身份执行
#  用法: bash /root/install.sh [--cn|--no-cn]
# ============================================================
set -o pipefail

if [ -t 1 ]; then
  R=$'\033[1;31m'; G=$'\033[1;32m'; Y=$'\033[1;33m'; C=$'\033[1;36m'; B=$'\033[1m'; N=$'\033[0m'
else
  R=''; G=''; Y=''; C=''; B=''; N=''
fi
info(){ printf '%s\n' "${C}[信息]${N} $*"; }
ok(){   printf '%s\n' "${G}[成功]${N} $*"; }
warn(){ printf '%s\n' "${Y}[注意]${N} $*"; }
err(){  printf '%s\n' "${R}[错误]${N} $*" >&2; }
die(){  err "$*"; exit 1; }
step(){ printf '\n%s\n' "${B}>>>> $* <<<<${N}"; }

USE_CN=1
for a in "$@"; do
  case "$a" in
    --cn)    USE_CN=1 ;;
    --no-cn) USE_CN=0 ;;
  esac
done

export DEBIAN_FRONTEND=noninteractive
export HOME=/root
export PATH="/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

QQ_DIR="/root/Napcat/opt/QQ"
NAPCAT_HOME="/root/Napcat/opt/QQ/resources/app/app_launcher/napcat"
NAPCAT_CFG="$NAPCAT_HOME/config"
ASTRBOT_DIR="/root/AstrBot"
UV_INDEX="https://pypi.tuna.tsinghua.edu.cn/simple"

# ------------------------------------------------------------
step "1/7  配置软件源"
if [ "$USE_CN" = "1" ]; then
  if [ -f /etc/apt/sources.list.d/debian.sources ]; then
    sed -i 's|deb.debian.org|mirrors.tuna.tsinghua.edu.cn|g' /etc/apt/sources.list.d/debian.sources
  fi
  if [ -f /etc/apt/sources.list ]; then
    sed -i 's|deb.debian.org|mirrors.tuna.tsinghua.edu.cn|g' /etc/apt/sources.list
    sed -i 's|security.debian.org|mirrors.tuna.tsinghua.edu.cn|g' /etc/apt/sources.list
  fi
  ok "已切换到清华镜像源"
else
  info "保持 Debian 默认源"
fi
apt update -y || die "apt update 失败，请检查网络连接"

# ------------------------------------------------------------
step "2/7  安装系统依赖"
apt install -y --no-install-recommends \
  sudo curl wget git ca-certificates unzip xz-utils procps \
  xvfb xauth libgcrypt20 python3 python3-pip \
  || die "系统依赖安装失败"
ok "系统依赖就绪"

# ------------------------------------------------------------
step "3/7  安装 NapCat（内含 QQ 客户端，下载较慢）"
if [ -x "$QQ_DIR/qq" ] && [ -f "$NAPCAT_HOME/napcat.mjs" ]; then
  ok "检测到已安装的 QQ/NapCat，跳过安装"
else
  cd /root || die "无法进入 /root"
  rm -f napcat.sh
  DL_OK=0
  for U in \
    "https://ghfast.top/https://raw.githubusercontent.com/NapNeko/NapCat-Installer/main/script/install.sh" \
    "https://ghproxy.net/https://raw.githubusercontent.com/NapNeko/NapCat-Installer/main/script/install.sh" \
    "https://raw.githubusercontent.com/NapNeko/NapCat-Installer/main/script/install.sh" ; do
    info "下载 NapCat 安装脚本 ..."
    if curl -fsSL --connect-timeout 20 --max-time 120 -o napcat.sh "$U"; then DL_OK=1; break; fi
  done
  [ "$DL_OK" = "1" ] || die "NapCat 安装脚本下载失败，请检查网络后重试"
  bash napcat.sh --docker n --cli n --proxy 0 || die "NapCat 安装失败"
  ok "NapCat 安装完成"
fi

# ------------------------------------------------------------
step "4/7  安装 uv（Python 包管理器）"
if command -v uv >/dev/null 2>&1; then
  ok "uv 已存在：$(uv --version)"
else
  curl -LsSf https://astral.sh/uv/install.sh -o /root/uv-install.sh 2>/dev/null && sh /root/uv-install.sh >/dev/null 2>&1
  export PATH="/root/.local/bin:$PATH"
  if ! command -v uv >/dev/null 2>&1; then
    warn "astral.sh 安装失败，改用 pip 安装 uv"
    pip3 install --break-system-packages -i "$UV_INDEX" uv 2>/dev/null \
      || pip3 install --break-system-packages uv \
      || die "uv 安装失败"
  fi
  ok "uv 安装完成"
fi
export PATH="/root/.local/bin:$PATH"

# ------------------------------------------------------------
step "5/7  安装 AstrBot"
if [ -x /root/.local/bin/astrbot ]; then
  ok "AstrBot 已安装，跳过"
else
  if [ "$USE_CN" = "1" ]; then
    export UV_DEFAULT_INDEX="$UV_INDEX"
  fi
  uv tool install astrbot --python 3.12 || die "AstrBot 安装失败"
  ok "AstrBot 安装完成"
fi

# ------------------------------------------------------------
step "6/7  初始化 AstrBot 并写入平台配置"
mkdir -p "$ASTRBOT_DIR"; cd "$ASTRBOT_DIR" || die "无法进入 $ASTRBOT_DIR"
/root/.local/bin/astrbot init -y || warn "astrbot init 返回非零（可能已初始化），继续"
if [ -f /root/patch_astrbot.py ]; then
  python3 /root/patch_astrbot.py "$ASTRBOT_DIR/data/cmd_config.json" || warn "AstrBot 平台配置写入失败（可稍后在面板手动添加）"
fi

mkdir -p "$NAPCAT_CFG"
if [ -f /root/onebot11.json ]; then
  if [ -f "$NAPCAT_CFG/onebot11.json" ]; then
    ok "NapCat 网络配置已存在，保持原样"
  else
    cp /root/onebot11.json "$NAPCAT_CFG/onebot11.json"
    ok "NapCat 反向 WS 配置已预置（登录后自动生效）"
  fi
fi

# ------------------------------------------------------------
step "7/7  收尾"
mkdir -p /root/logs
chmod +x /root/*.sh 2>/dev/null
ok "全部安装完成"

echo
printf '%s\n' "${B}================ 安装结果 ================${N}"
printf '  QQ + NapCat : %s\n' "$QQ_DIR"
printf '  NapCat 配置 : %s\n' "$NAPCAT_CFG"
printf '  AstrBot     : %s\n' "$ASTRBOT_DIR"
printf '  AstrBot 面板: %s\n' "http://127.0.0.1:6185"
printf '  NapCat 面板 : %s\n' "http://127.0.0.1:6099"
printf '%s\n' "${B}==========================================${N}"
echo
info "接下来在 Termux 里运行：  bash ~/astrbot-napcat/abot start"
