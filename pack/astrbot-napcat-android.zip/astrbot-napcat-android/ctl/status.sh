#!/usr/bin/env bash
# 查看运行状态
set -o pipefail

CT="${CT_NAME:-astrbot}"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
ROOTFS="$PREFIX/var/lib/proot-distro/installed-rootfs/$CT"

echo "=========== 服务状态 ==========="

sess_running() { screen -ls 2>/dev/null | grep -q "[.]$1[[:space:]]"; }

if sess_running napcat;  then echo "  NapCat  : ✅ 运行中"; else echo "  NapCat  : ⛔ 未运行"; fi
if sess_running astrbot; then echo "  AstrBot : ✅ 运行中"; else echo "  AstrBot : ⛔ 未运行"; fi

echo
echo "=========== 端口探测 ==========="
check_port() {
  local name="$1" url="$2"
  local code
  code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 "$url" 2>/dev/null)"
  if [ -n "$code" ] && [ "$code" != "000" ]; then
    echo "  $name : ✅ 可访问 (HTTP $code)  $url"
  else
    echo "  $name : ⛔ 无响应        $url"
  fi
}
check_port "AstrBot 面板(6185)" "http://127.0.0.1:6185/"
check_port "NapCat  面板(6099)" "http://127.0.0.1:6099/"

echo
echo "=========== 登录状态 ==========="
if [ -d "$ROOTFS" ]; then
  QQNUM="$(ls "$ROOTFS/root/.config/QQ/versions" 2>/dev/null | head -1)"
  CFGDIR="$ROOTFS/root/Napcat/opt/QQ/resources/app/app_launcher/napcat/config"
  if ls "$CFGDIR"/onebot11_*.json >/dev/null 2>&1; then
    echo "  已登录账号配置: $(ls "$CFGDIR"/onebot11_*.json | sed 's/.*onebot11_//; s/\.json//' | tr '\n' ' ')"
  else
    echo "  尚未检测到已登录账号（首次使用请运行: bash abot login）"
  fi
fi

echo
echo "  面板地址（手机浏览器打开）："
echo "    AstrBot : http://127.0.0.1:6185"
echo "    NapCat  : http://127.0.0.1:6099"
echo "  获取 NapCat 带 token 的直达链接:  bash abot login"
echo
