#!/usr/bin/env bash
# 启动 AstrBot + NapCat（后台运行）
set -o pipefail

CT="${CT_NAME:-astrbot}"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
BASE="$(cd "$(dirname "$0")/.." && pwd)"
ROOTFS="$PREFIX/var/lib/proot-distro/installed-rootfs/$CT"
LOGDIR="$BASE/logs"

# 若没通过环境变量指定 QQ 号，则读取安装时保存的 qq.txt
if [ -z "${QQ:-}" ] && [ -f "$BASE/qq.txt" ]; then
  QQ="$(head -n 1 "$BASE/qq.txt" | tr -d ' \t\r\n')"
fi

if [ ! -d "$ROOTFS" ]; then
  echo "[错误] 未找到容器 '$CT'，请先运行:  bash $BASE/一键安装.sh"
  exit 1
fi
if ! command -v screen >/dev/null 2>&1; then
  echo "[错误] 缺少 screen，请执行:  pkg install screen"
  exit 1
fi

mkdir -p "$LOGDIR" "$ROOTFS/root/logs"

sess_running() {
  screen -ls 2>/dev/null | grep -q "[.]$1[[:space:]]"
}

# ---------- NapCat ----------
if sess_running napcat; then
  echo "[信息] NapCat 已在运行"
else
  NAPCAT_CMD="proot-distro login $CT -- bash /root/start-napcat.sh"
  if [ -n "${QQ:-}" ]; then
    NAPCAT_CMD="$NAPCAT_CMD $QQ"
    echo "[信息] 使用快速登录账号: $QQ"
  fi
  screen -dmS napcat bash -c "$NAPCAT_CMD >> '$LOGDIR/napcat.log' 2>&1"
  sleep 2
  echo "[成功] NapCat 已启动"
fi

# ---------- AstrBot ----------
if sess_running astrbot; then
  echo "[信息] AstrBot 已在运行"
else
  screen -dmS astrbot bash -c "proot-distro login $CT -- bash /root/start-astrbot.sh >> '$LOGDIR/astrbot.log' 2>&1"
  sleep 2
  echo "[成功] AstrBot 已启动"
fi

echo
echo "  AstrBot 面板 : http://127.0.0.1:6185"
echo "  NapCat  面板 : http://127.0.0.1:6099"
echo
echo "  下一步:"
echo "    1) 首次使用先扫码登录 QQ      ->  bash abot login"
echo "    2) 查看日志                   ->  bash abot logs"
echo "    3) 查看状态                   ->  bash abot status"
echo
