#!/usr/bin/env bash
# 彻底卸载：删除容器与懒人包脚本
set -o pipefail

CT="${CT_NAME:-astrbot}"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
ROOTFS="$PREFIX/var/lib/proot-distro/installed-rootfs/$CT"
BASE="$(cd "$(dirname "$0")/.." && pwd)"

echo "=============================================="
echo " 警告：本操作会删除容器 '$CT' 及其全部数据"
echo "       （QQ 登录状态、AstrBot 配置、插件）"
echo "=============================================="
printf " 确认请输入 yes : "
read -r ans
if [ "$ans" != "yes" ]; then
  echo "已取消。"
  exit 0
fi

echo
echo "[信息] 停止服务 ..."
bash "$(dirname "$0")/stop.sh" || true

echo "[信息] 删除容器 '$CT' ..."
proot-distro remove "$CT" && echo "[成功] 容器已删除"

echo
printf " 是否一并删除脚本目录 %s ? 输入 yes 删除: " "$BASE"
read -r ans2
if [ "$ans2" = "yes" ]; then
  cd / 2>/dev/null || true
  rm -rf "$BASE"
  echo "[成功] 脚本目录已删除"
else
  echo "[信息] 保留脚本目录: $BASE"
fi

echo
echo "[成功] 卸载完成。"
