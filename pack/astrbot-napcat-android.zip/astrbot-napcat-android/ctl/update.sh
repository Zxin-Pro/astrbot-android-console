#!/usr/bin/env bash
# 更新 NapCat 与 AstrBot 到最新版本
set -o pipefail

CT="${CT_NAME:-astrbot}"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
ROOTFS="$PREFIX/var/lib/proot-distro/installed-rootfs/$CT"

if [ ! -d "$ROOTFS" ]; then
  echo "[错误] 未找到容器 '$CT'。"
  exit 1
fi

echo "[信息] 更新 AstrBot ..."
proot-distro login "$CT" -- bash -c 'export HOME=/root; export PATH="/root/.local/bin:$PATH"; uv tool upgrade astrbot' \
  && echo "[成功] AstrBot 已更新" \
  || echo "[注意] AstrBot 更新失败（可稍后重试）"

echo
echo "[信息] 更新 NapCat（会重装 QQ/NapCat 组件，稍慢）..."
proot-distro login "$CT" -- bash -c 'cd /root && rm -f napcat.sh && (curl -fsSL -o napcat.sh https://ghfast.top/https://raw.githubusercontent.com/NapNeko/NapCat-Installer/main/script/install.sh || curl -fsSL -o napcat.sh https://ghproxy.net/https://raw.githubusercontent.com/NapNeko/NapCat-Installer/main/script/install.sh || curl -fsSL -o napcat.sh https://raw.githubusercontent.com/NapNeko/NapCat-Installer/main/script/install.sh) && bash napcat.sh --docker n --cli n --proxy 0 --force' \
  && echo "[成功] NapCat 已更新" \
  || echo "[注意] NapCat 更新失败（可稍后重试）"

echo
echo "[信息] 更新完成。建议重启服务:  bash abot restart"
