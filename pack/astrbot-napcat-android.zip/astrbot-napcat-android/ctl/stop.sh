#!/usr/bin/env bash
# 停止 AstrBot + NapCat
set -o pipefail

CT="${CT_NAME:-astrbot}"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
ROOTFS="$PREFIX/var/lib/proot-distro/installed-rootfs/$CT"

echo "[信息] 正在停止服务 ..."

if [ -d "$ROOTFS" ]; then
  proot-distro login "$CT" -- bash /root/stop-all.sh 2>/dev/null || true
fi

screen -S napcat -X quit 2>/dev/null && echo "[信息] 已关闭 NapCat 会话"
screen -S astrbot -X quit 2>/dev/null && echo "[信息] 已关闭 AstrBot 会话"

echo "[成功] 已停止。"
