#!/usr/bin/env bash
# 查看运行日志
set -o pipefail

BASE="$(cd "$(dirname "$0")/.." && pwd)"
LOGDIR="$BASE/logs"
WHICH="${1:-both}"

show() {
  local n="$1"
  local f="$LOGDIR/$n.log"
  echo "=========== $n 日志（最后 60 行） ==========="
  if [ -f "$f" ]; then
    tail -n 60 "$f"
  else
    echo "(暂无日志，服务可能还没启动)"
  fi
  echo
}

case "$WHICH" in
  napcat)  show napcat ;;
  astrbot) show astrbot ;;
  both)    show napcat; show astrbot ;;
  *)       echo "用法: bash abot logs [napcat|astrbot]"; exit 1 ;;
esac

echo "  实时跟踪日志:  tail -f $LOGDIR/napcat.log"
echo
