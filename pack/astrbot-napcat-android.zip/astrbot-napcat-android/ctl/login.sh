#!/usr/bin/env bash
# 获取 QQ 扫码登录方式 + NapCat 面板直达链接
set -o pipefail

CT="${CT_NAME:-astrbot}"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
ROOTFS="$PREFIX/var/lib/proot-distro/installed-rootfs/$CT"
WEBUI_JSON="$ROOTFS/root/Napcat/opt/QQ/resources/app/app_launcher/napcat/config/webui.json"

if [ ! -d "$ROOTFS" ]; then
  echo "[错误] 未找到容器 '$CT'，请先运行一键安装。"
  exit 1
fi

echo "============ QQ 登录指引 ============"
echo

TOKEN=""
if [ -f "$WEBUI_JSON" ]; then
  TOKEN="$(tr -d '\n\r' < "$WEBUI_JSON" | sed -n 's/.*"token"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')"
fi

if [ -n "$TOKEN" ]; then
  echo "  NapCat 面板直达链接（复制到手机浏览器打开）:"
  echo
  echo "    http://127.0.0.1:6099/webui?token=$TOKEN"
  echo
  echo "  也可以先打开 http://127.0.0.1:6099 ，再手动填入 Token:"
  echo "    $TOKEN"
  echo
else
  echo "  ⚠ 未找到 webui.json —— NapCat 可能还没启动过，先执行:  bash abot start"
  echo
fi

cat <<'EOT'
---------- 首次登录 QQ 的两种方式 ----------

方式 A（推荐，只用一个手机也行）
  1. 手机浏览器打开上面的 NapCat 面板链接
  2. 面板里会显示登录二维码
  3. 截图二维码
  4. 打开手机 QQ → 右上角「+」→ 扫一扫 → 右上角「相册」→ 选中刚截的图
  5. 手机上确认登录，NapCat 立即上线

方式 B（看终端里的字符二维码）
  1. Termux 里执行:  screen -r napcat
  2. 终端会打印出字符二维码，用另一台手机扫码
  3. 看完按 Ctrl+A 再按 D 退出（不会关闭后台进程）

登录成功之后：
  · NapCat 会自动按预置配置，以「反向 WS」连到 AstrBot 的 6199 端口
  · 打开 AstrBot 面板 → 平台，能看到 aiocqhttp 已连接
  · 若没反应，执行一次:  bash abot restart

下次开机免扫码快速登录：
  bash abot start          # 若安装时填过 QQ 号会自动带上；否则：
  QQ=你的QQ号 bash abot start

EOT
