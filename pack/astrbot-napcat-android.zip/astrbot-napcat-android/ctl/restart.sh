#!/usr/bin/env bash
# 重启 AstrBot + NapCat
set -o pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
bash "$HERE/stop.sh"
sleep 2
bash "$HERE/start.sh" "$@"
